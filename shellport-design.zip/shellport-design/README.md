# Shellport – Design-Übergabe (SSH/SFTP-Client)

Klickbarer Design-Dummy für einen Desktop-SSH/SFTP-Client. Ziel: SSH-Funktionen im Stil von Termius, SFTP-Funktionen im Stil von WinSCP. Modernes, dunkles Design (Standard), optional hell. „Shellport“ ist ein Arbeitstitel.

Dieses Paket ist eine **Spezifikation**, kein lauffähiger Code. Baue die App im gewählten Stack nach; Layout, Farben, Texte und Verhalten sollen den Screens entsprechen.

## Inhalt

```
README.md                  diese Datei
tokens/tokens.css          Design-Tokens als CSS-Variablen (dark + .light)
tokens/tokens.json         dieselben Tokens + Radien, Größen, Semantik
tokens/terminal-schemes.json  9 Terminal-Farbschemata + Schriftgrößen-Range
screens/*.dc.html          10 Screens (Quelltext der Mockups)
screens/canvas.json        Canvas-Index: Screen-Titel, Reihenfolge, Notizen
```

## Das .dc.html-Format lesen

Die Screens stammen aus einem Design-Tool mit eigenem Template-Format. Die zugehörige Runtime (`support.js`) ist **nicht** enthalten, die Dateien laufen also nicht direkt im Browser. So liest du sie:

- Markup in `<x-dc>` ist normales HTML mit Inline-Styles. Alle Farben sind `var(--token)` aus `tokens.css`.
- `<helmet>` enthält globale Styles (Font-Import, Tokens, Hover-Regeln, Keyframes).
- `{{name}}` = Wert aus `renderVals()`/`vals()` im `<script type="text/x-dc">` am Dateiende.
- `<sc-for list="{{items}}" as="x">` = Schleife, `<sc-if value="{{cond}}">` = Bedingung.
- `onClick="{{fn}}"` = Event-Handler aus dem Script. `state`/`setState` wie bei einer React-Klassenkomponente.
- `<a href="X.dc.html">` = Navigation zu Screen X.
- `data-props` = Designer-Tweaks (z. B. `theme`, `variant`, `speed`), für die App nicht relevant.
- Alle Host-Daten, Fingerprints, Logs und Dateilisten sind **Beispieldaten**.

## Screens

| Datei | Screen | Kernfunktionen |
|---|---|---|
| Main.dc.html | Server-Übersicht | Host-Karten, Gruppen, Login-Profile, Filter Alle/SSH/SFTP, Suche (⌘K), Quick Connect `user@host:port`, Detail-Panel (Adresse, Profil, Jump-Host, Startpfad, Fingerprint, Port-Forwarding), Aktionen Terminal/Dateien/Bearbeiten |
| SSH.dc.html | Terminal (Termius-artig) | Sitzungs-Tabs, Split-Panes, direkte Eingabe im Terminal, Broadcast an alle Bereiche, Befehlsleiste (optional), Seitenleiste: Snippets, Tunnel, Sitzungsinfo, Design (Farbschema + Schriftgröße), Verbindungsverlust-Ansicht mit Auto-Reconnect-Countdown, Sitzung beenden per `exit` |
| SFTP.dc.html | Dateimanager (WinSCP-artig) | Commander-Ansicht Lokal/Remote, Pfad-Breadcrumbs, Lesezeichen, Toolbar (Hochladen, Herunterladen, Neuer Ordner, Umbenennen, Bearbeiten, Rechte, Löschen, Synchronisieren, Vergleichen, Aktuell halten), Sync-Browsing, versteckte Dateien, Übertragungsmodus, Warteschlange (laufend/fertig/Fehler), Dialoge „Datei existiert bereits“ und „Endgültig löschen?“ |
| Edit.dc.html | Host / Login-Profil bearbeiten (Modal) | Umschalter Host ↔ Login-Profil. Host-Reiter: Allgemein, Authentifizierung (Profil oder individuell; Passwort, Schlüssel, SSH-Agent, Interaktiv/2FA), Verbindung (ProxyJump, Keepalive, Timeout, Startbefehl, Env, Port-Forwarding), SFTP (Startverzeichnisse, Modus, Parallelität, Rechte, Bandbreite, sudo-sftp-server). „Verbindung testen“ |
| ConnectSSH.dc.html | Laden: SSH | Schrittliste (Jump-Host, Host-Key, Anmelden, Kanal, Shell), Fortschrittsbalken, aufklappbares `ssh -v`-Log, Abbrechen; danach automatisch ins Terminal |
| ConnectSFTP.dc.html | Laden: SFTP | wie oben im SFTP-Layout (TCP, Host-Key, Anmelden, SFTP-Subsystem, Verzeichnis laden) |
| HostKeyNew.dc.html | Unbekannter Host-Key | Fingerprint SHA256/MD5, Kopieren, „Nur dieses Mal“, „Vertrauen und verbinden“ |
| HostKeyChanged.dc.html | Host-Key geändert (Warnung) | Vergleich gespeichert/aktuell, Original-OpenSSH-Warnung, Ersetzen erst nach Bestätigungs-Checkbox, Primäraktion „Verbindung abbrechen“ |
| ErrorConnection.dc.html | Verbindungsfehler | Varianten Zeitüberschreitung / abgelehnt / Host nicht gefunden, mögliche Ursachen, Originalmeldung, Erneut versuchen (Versuchszähler), Auto-Retry-Option |
| ErrorAuth.dc.html | Anmeldung fehlgeschlagen | abgelehnte Methoden, Passwort neu eingeben (Leer-Validierung), im Profil speichern, Login-Profil bearbeiten |

## Navigation (Dummy-Szenarien)

- Rail links: Hosts → Main, Terminal → SSH, SFTP → SFTP, unten Hell/Dunkel-Umschalter.
- Host verbinden: Ladescreen → Terminal bzw. Dateimanager.
- Szenarien je Beispiel-Host: web-prod-01, db-prod-01, bastion, kunde-cms = Erfolg · coolify-01 = unbekannter Host-Key · staging-app = Host-Key geändert · kunde-shop = Anmeldung fehlgeschlagen · nas = Zeitüberschreitung.
- In der App entscheidet natürlich der echte Verbindungsverlauf, welcher Screen erscheint.

## Design-System

- Schriften: IBM Plex Sans (UI), JetBrains Mono (Hosts, Pfade, Terminal, Fingerprints).
- Farbsemantik: Türkis = SSH/Primär, Amber = SFTP/Warnung, Rot = Fehler/destruktiv, Grün = verbunden/fertig.
- Theming: Tokens als CSS-Variablen auf dem App-Root, `.light` überschreibt. Standard dunkel; Wahl persistent speichern.
- Terminal-Schema unabhängig vom App-Design wählbar; „Wie App-Design“ folgt Hell/Dunkel. Werte in `terminal-schemes.json`.
- Layout: Rail 64 px, Sidebar 220–240 px, Detail-Panel 300–360 px, Tab-Leiste 44–48 px. Buttons 34–44 px hoch, Radien 6/8/10/12/16.
- Icons: Inline-SVG, 24er viewBox, Stroke 1,8, runde Enden (Lucide-Stil passt).
- Barrierefreiheit: echte `button`/`a`/`input`+`label`, `aria-label` an Icon-Buttons, `role="tab"`/`radio`/`dialog`, Kontrast ≥ 4,5:1 in beiden Modi.

## Abgeleitetes Datenmodell (Vorschlag aus dem Mockup)

- Host: name, address, port, user, group, tags[], protocols {ssh, sftp, scp}, color, notes, loginProfileId | eigene Credentials, jumpHostId, keepalive, timeout, startCommand, env, forwards[], sftp {remoteStart, localStart, transferMode, parallel, uploadPerms, bandwidthLimit, sftpServerCmd}, knownHostKey
- LoginProfile: name, user, method (password | key | agent | keyboard-interactive), keyRef, passphrase?, storeInVault, usedBy (Anzahl Hosts)
- PortForward: type (L | R | D), bind, target, autostart
- Snippet: name, scope (global | Gruppe | Host-Pattern), command
- TransferJob: direction, source, target, progress, speed, state (waiting | running | done | error), error

## Nicht im Umfang / Platzhalter

- Rail-Einträge Snippets, Schlüsselbund, Port-Forwarding, Einstellungen haben noch keine eigenen Screens.
- Tunnel-, Synchronisieren- und Rechte-Dialog sind nur als Buttons vorhanden.
- „Gilt für“ beim Terminal-Schema und der Sync-Status („Verschlüsselter Tresor“) sind nur angedeutet.
- Keine Mobile-Ansicht vorgesehen (Desktop-App).
